from threading import Timer

class RepeatedTimer(object):
    """
    A class usefull to run a function, every interval in seconds, in another thread.
    Here we launch a new thread every interval.
    """
    def __init__(self, interval, function, *args):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False
        
class RepeatedTimerMode(object):
    """
    A class usefull to run a function, every interval in seconds, in another thread.
    Here we launch a new thread only when interval is passed and that self._run finished.
    """
    def __init__(self, interval, function, *args):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.is_running = False
        self.start()

    def _run(self):
        self.function(*self.args)
        self.is_running = False
        self.start()

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False